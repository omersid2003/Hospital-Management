<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/aboutus.css">
    <title>About Us</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        
    </style>
</head>
<body>

<!-- Hero Section -->
<div class="hero">
    <div class="hero-overlay"></div>
    <div class="hero-content">
        <h1 class="display-4">Empowering Innovation, Together</h1>
        <p class="lead">Driven by passion, innovation, and a relentless commitment to making a difference.</p>
        <a href="#our-story" class="btn btn-primary btn-lg">Learn More</a>
    </div>
</div>

<!-- Our Story Section -->
<section id="our-story" class="container py-5">
    <div class="row align-items-center">
        <div class="col-md-6">
            <h2>Our Story</h2>
            <p>At <strong>MedConnect</strong>, our journey began with a simple yet profound mission: to transform healthcare through innovation and efficiency. Founded in [Year], we envisioned a world where hospitals and clinics could seamlessly manage operations, prioritize patient care, and minimize administrative burdens. Our Hospital Management System was crafted to bridge the gap between technology and healthcare, offering intuitive solutions that empower medical professionals, streamline workflows, and enhance patient experiences. Guided by our core values — Excellence, Innovation, and Compassion — we remain dedicated to revolutionizing healthcare management for a healthier tomorrow.</p>
        </div>
        <div class="col-md-6">
            <img src="img/bg010.jpeg" alt="Our Journey" class="img-fluid rounded">
        </div>
    </div>
</section>

<!-- Team Section -->
 
<section id="team" class="py-5 bg-light">
    <div class="container">
        <h2 class="text-center mb-5">Meet Our Team</h2>
        <div class="row text-center">
            <div class="col-md-7">
                <img src="img/omer.jpg" alt="Team Member" class="team-img">
                <h5 class="mt-3">Omer Siddiqui</h5>
                <p>22K-4266</p>
            </div>
            <div class="col-md-3">
                <img src="img/asif.jpg" alt="Team Member" class="team-img">
                <h5 class="mt-3">Abdullah Asif</h5>
                <p>22K-4560</p>
            </div>
        </div>
    </div>
</section>

<section id="stats" class="container py-5">
    <h2 class="text-center mb-5">What Drives Us</h2>
    <div class="row text-center">
        <center>
        <div class="col-md-5">
            <div class="stat-card" >
                <h3>500+</h3>
                <p>Customers Served</p>
            </div>
        </div>
        <div class="col-md-5">
            <div class="stat-card">
                <h3>95%</h3>
                <p>Customer Satisfaction</p>
            </div>
        </div>
</center>
    </div>
</section>

<!-- CTA Section -->
<section id="cta" class="cta-section">
    <h2>Let’s Shape the Future Together</h2>
    <p class="mb-4">Ready to collaborate? Let’s start building something great.</p>
    <a href="contact.php" class="btn btn-light btn-lg">Contact Us</a>
</section>

<!-- Footer -->
<footer class="bg-dark text-white text-center py-3">
    <p>© <?php echo date("Y"); ?> MedConnect. All rights reserved.</p>
</footer>

<!-- Include Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
