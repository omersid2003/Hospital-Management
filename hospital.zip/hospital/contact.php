<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/contact.css">
    <title>Contact Us</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<!-- Hero Section -->
<div class="hero">
    <div class="hero-overlay"></div>
    <div class="hero-content">
        <h1 class="display-4">Get in Touch</h1>
        <p class="lead">We’re here to help. Reach out to us anytime.</p>
    </div>
</div>

<!-- Contact Form Section -->
<section class="container py-5">
    <div class="row">
        <div class="col-md-6">
            <h2>Contact Us</h2>
            <p>Feel free to fill out the form below to reach us. We'll get back to you as soon as possible.</p>
            <form action="contact_process.php" method="POST">
                <div class="mb-3">
                    <label for="name" class="form-label">Name</label>
                    <input type="text" class="form-control" id="name" name="name" placeholder="Your Name" required>
                </div>
                <div class="mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" class="form-control" id="email" name="email" placeholder="Your Email" required>
                </div>
                <div class="mb-3">
                    <label for="subject" class="form-label">Subject</label>
                    <input type="text" class="form-control" id="subject" name="subject" placeholder="Subject" required>
                </div>
                <div class="mb-3">
                    <label for="message" class="form-label">Message</label>
                    <textarea class="form-control" id="message" name="message" rows="5" placeholder="Your Message" required></textarea>
                </div>
                <button type="submit" class="btn btn-primary btn-lg">Send Message</button>
            </form>
        </div>
        <div class="col-md-6">
            <h2>Our Contact Information</h2>
            <div class="contact-info">
                <div>
                    <i class="bi bi-telephone-fill"></i>
                    <h5>Phone</h5>
                    <p>+92 345 9521643</p>
                </div>
                <div>
                    <i class="bi bi-envelope-fill"></i>
                    <h5>Email</h5>
                    <p>contactus@medconnect.com</p>
                </div>
                <div>
                    <i class="bi bi-geo-alt-fill"></i>
                    <h5>Address</h5>
                    <p>FAST, NUCES, Shah Latif Town, Karachi</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Footer -->
<footer class="bg-dark text-white text-center py-3">
    <p>© <?php echo date("Y"); ?> MedConnect. All rights reserved.</p>
</footer>

<!-- Include Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
