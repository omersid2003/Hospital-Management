<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/animations.css">  
    <link rel="stylesheet" href="css/main.css">  
    <link rel="stylesheet" href="css/signup.css">
        
    <title>Create Account</title>
    <style>
        .container{
            animation: transitionIn-X 0.5s;
        }
    </style>
</head>
<body>

<!-- Toast Notification -->
<div id="toast" style="visibility: hidden; 
    position: fixed; 
    left: 50%; 
    bottom: 30px; 
    background: linear-gradient(90deg, #4CAF50, #0ad867); 
    color: #ffffff; 
    text-align: center; 
    padding: 16px 24px; 
    border-radius: 8px; 
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2); 
    font-family: Arial, sans-serif; 
    font-size: 16px; 
    font-weight: bold; 
    transform: translateX(-50%) translateY(50px); 
    opacity: 0; 
    transition: all 0.5s ease;">
    Account Successfully Created
</div>

<script>
    function showToast() {
        var toast = document.getElementById("toast");
        toast.style.visibility = "visible";
        toast.style.opacity = "1";
        toast.style.transform = "translateX(-50%) translateY(0)";
        
        setTimeout(function() {
            toast.style.opacity = "0";
            toast.style.transform = "translateX(-50%) translateY(50px)";
            setTimeout(function() {
                toast.style.visibility = "hidden";
            }, 500); // Wait for fade-out to complete
        }, 3000); // Display for 3 seconds
    }
</script>


<?php

session_start();
$_SESSION["user"]="";
$_SESSION["usertype"]="";
date_default_timezone_set('Asia/Karachi');
$date = date('Y-m-d');
$_SESSION["date"]=$date;

include("connection.php");

if($_POST){
    $result= $database->query("select * from webuser");

    $fname=$_SESSION['personal']['fname'];
    $lname=$_SESSION['personal']['lname'];
    $name=$fname." ".$lname;
    $address=$_SESSION['personal']['address'];
    $cnic=$_SESSION['personal']['cnic'];
    $dob=$_SESSION['personal']['dob'];
    $email=$_POST['newemail'];
    $tele=$_POST['tele'];
    $newpassword=$_POST['newpassword'];
    $cpassword=$_POST['cpassword'];
    
    if ($newpassword==$cpassword){
        $sqlmain= "select * from webuser where email=?;";
        $stmt = $database->prepare($sqlmain);
        $stmt->bind_param("s",$email);
        $stmt->execute();
        $result = $stmt->get_result();
        if($result->num_rows==1){
            $error='<label for="promter" class="form-label" style="color:rgb(255, 62, 62);text-align:center;">Already have an account for this Email address.</label>';
        }else{
            $database->query("insert into patient(pemail,pname,ppassword, paddress, pcnic,pdob,ptel) values('$email','$name','$newpassword','$address','$cnic','$dob','$tele');");
            $database->query("insert into webuser values('$email','p')");

         /*
        $subject = "Welcome to Our Website!";
        $message = "Dear $fname $lname,\n\nWe Welcome You on Joining our Newly Launched\nFAST Medical Services! We are glad to have you on-board.\n\nBest Regards,\nFAST Medical";
        $headers = "From: no-reply@yFASTmedical.com"; // Replace with your domain email
        if (mail($email, $subject, $message, $headers)) {
            // Email sent successfully
        } else {
            // Email sending failed
            echo "Email sending failed.";
        }
            */

            // Show the toast after account creation
            echo "<script>
                    setTimeout(function(){ showToast(); }, 1000);
                    setTimeout(function(){ window.location.href = 'patient/index.php'; }, 4000);
                  </script>";

            $_SESSION["user"]=$email;
            $_SESSION["usertype"]="p";
            $_SESSION["username"]=$fname;

            $error='<label for="promter" class="form-label" style="color:rgb(255, 62, 62);text-align:center;"></label>';
        }
        
    }else{
        $error='<label for="promter" class="form-label" style="color:rgb(255, 62, 62);text-align:center;">Password Confirmation Error! Reconfirm Password</label>';
    }

    
}else{
    $error='<label for="promter" class="form-label"></label>';
}
?>
<center>
    <div class="container">
        <table border="0" style="width: 69%;">
            <tr>
                <td colspan="2">
                    <p class="header-text">Let's Get Started</p>
                    <p class="sub-text">It's Okay, Now Create User Account.</p>
                </td>
            </tr>
            <tr>
                <form action="" method="POST" >
                <td class="label-td" colspan="2">
                    <label for="newemail" class="form-label">Email: </label>
                </td>
            </tr>
            <tr>
                <td class="label-td" colspan="2">
                    <input type="email" name="newemail" class="input-text" placeholder="Email Address" required>
                </td>
                
            </tr>
            <tr>
                <td class="label-td" colspan="2">
                    <label for="tele" class="form-label">Mobile Number: </label>
                </td>
            </tr>
            <tr>
                <td class="label-td" colspan="2">
                    <input type="tel" name="tele" class="input-text" placeholder="03XX-XXXXXXX" pattern="[0]{1}[3]{1}[0-9]{2}-[0-9]{7}" required>
                </td>
            </tr>
            <tr>
            <tr>
    <td class="label-td" colspan="2">
        <label for="newpassword" class="form-label">Create New Password: </label>
    </td>
</tr>
<tr>
    <td class="label-td" colspan="2">
        <input type="password" id="newpassword" name="newpassword" class="input-text" placeholder="New Password" required
               pattern="(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}"
               title="Password must contain at least one uppercase letter, one lowercase letter, one number, and one special character. Minimum length 8 characters.">
    </td>
    <td>
        <!-- Eye Icon for New Password Show/Hide -->
        <i id="toggle-newpassword-icon" class="fa fa-eye" onclick="togglePassword('newpassword')" style="cursor: pointer;"></i>
    </td>
</tr>

<tr>
    <td class="label-td" colspan="2">
        <label for="cpassword" class="form-label">Confirm Password: </label>
    </td>
</tr>
<tr>
    <td class="label-td" colspan="2">
        <input type="password" id="cpassword" name="cpassword" class="input-text" placeholder="Confirm Password" required>
    </td>
    <td>
        <!-- Eye Icon for Confirm Password Show/Hide -->
        <i id="toggle-cpassword-icon" class="fa fa-eye" onclick="togglePassword('cpassword')" style="cursor: pointer;"></i>
    </td>
</tr>

<!-- Include Font Awesome for icons -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

<script>
    // Function to toggle the password visibility for the given field
    function togglePassword(fieldId) {
        var passwordField = document.getElementById(fieldId);
        var toggleIcon = document.getElementById("toggle-" + fieldId + "-icon");

        // Toggle password visibility based on the input type
        if (passwordField.type === "password") {
            passwordField.type = "text";  // Show password
            toggleIcon.classList.remove("fa-eye");
            toggleIcon.classList.add("fa-eye-slash");  // Change to eye-slash icon
        } else {
            passwordField.type = "password";  // Hide password
            toggleIcon.classList.remove("fa-eye-slash");
            toggleIcon.classList.add("fa-eye");  // Change back to eye icon
        }
    }
</script>

     
            <tr>
                
                <td colspan="2">
                    <?php echo $error ?>

                </td>
            </tr>
            
            <tr>
                <td>
                    <input type="reset" value="Reset" class="login-btn btn-primary-soft btn" >
                </td>
                <td>
                    <input type="submit" value="Sign Up" class="login-btn btn-primary btn">
                </td>

            </tr>
            <tr>
                <td colspan="2">
                    <br>
                    <label for="" class="sub-text" style="font-weight: 280;">Already have an account&#63; </label>
                    <a href="login.php" class="hover-link1 non-style-link">Login</a>
                    <br><br><br>
                </td>
            </tr>

                    </form>
            </tr>
        </table>
    </div>
</center>
</body>
</html>