SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";



-- Table structure for table `admin`
DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `aemail` varchar(255) NOT NULL,
  `apassword` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`aemail`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



-- Dumping data for table `admin`
INSERT INTO `admin` (`aemail`, `apassword`) VALUES
('admin@medconnect.com', 'medconnect123');


-- Table structure for table `appointment`
DROP TABLE IF EXISTS `appointment`;
CREATE TABLE IF NOT EXISTS `appointment` (
  `appoid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(10) DEFAULT NULL,
  `apponum` int(3) DEFAULT NULL,
  `scheduleid` int(10) DEFAULT NULL,
  `appodate` date DEFAULT NULL,
  PRIMARY KEY (`appoid`),
  KEY `pid` (`pid`),
  KEY `scheduleid` (`scheduleid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;



-- Dumping data for table `appointment`
INSERT INTO `appointment` (`appoid`, `pid`, `apponum`, `scheduleid`, `appodate`) VALUES
(1, 1, 1, 1, '2022-06-03');




-- Table structure for table `doctor`
DROP TABLE IF EXISTS `doctor`;
CREATE TABLE IF NOT EXISTS `doctor` (
  `docid` int(11) NOT NULL AUTO_INCREMENT,
  `docemail` varchar(255) DEFAULT NULL,
  `docname` varchar(255) DEFAULT NULL,
  `docpassword` varchar(255) DEFAULT NULL,
  `doc_cnic` varchar(15) DEFAULT NULL,
  `doctel` varchar(15) DEFAULT NULL,
  `specialtyid` int(2) DEFAULT NULL,
  PRIMARY KEY (`docid`),
  KEY `specialties` (`specialtyid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;



-- Dumping data for table `doctor`
INSERT INTO `doctor` (`docid`, `docemail`, `docname`, `docpassword`, `doc_cnic`, `doctel`, `specialtyid`) VALUES
(1, 'doctor@medconnect.com', 'Test Doctor', '123', '000000000', '0110000000', 1);



-- Table structure for table `patient`
DROP TABLE IF EXISTS `patient`;
CREATE TABLE IF NOT EXISTS `patient` (
  `pid` int(11) NOT NULL AUTO_INCREMENT,
  `pemail` varchar(255) DEFAULT NULL,
  `pname` varchar(255) DEFAULT NULL,
  `ppassword` varchar(255) DEFAULT NULL,
  `paddress` varchar(255) DEFAULT NULL,
  `pcnic` varchar(15) DEFAULT NULL,
  `pdob` date DEFAULT NULL,
  `ptel` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;



-- Dumping data for table `patient`
INSERT INTO `patient` (`pid`, `pemail`, `pname`, `ppassword`, `paddress`, `pcnic`, `pdob`, `ptel`) VALUES
(1, 'patient@medconnect.com', 'Test Patient', '123', 'FAST, Karachi', '0000000000', '2000-01-01', '0120000000');



-- Table structure for table `schedule`
DROP TABLE IF EXISTS `schedule`;
CREATE TABLE IF NOT EXISTS `schedule` (
  `scheduleid` int(11) NOT NULL AUTO_INCREMENT,
  `docid` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `scheduledate` date DEFAULT NULL,
  `scheduletime` time DEFAULT NULL,
  `nop` int(4) DEFAULT NULL,
  PRIMARY KEY (`scheduleid`),
  KEY `docid` (`docid`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;



-- Dumping data for table `schedule`
INSERT INTO `schedule` (`scheduleid`, `docid`, `title`, `scheduledate`, `scheduletime`, `nop`) VALUES
(1, '1', 'Test Session', '2050-01-01', '18:00:00', 50),
(2, '1', '1', '2022-06-10', '20:36:00', 1),
(3, '1', '12', '2022-06-10', '20:33:00', 1),
(4, '1', '1', '2022-06-10', '12:32:00', 1),
(5, '1', '1', '2022-06-10', '20:35:00', 1),
(6, '1', '12', '2022-06-10', '20:35:00', 1),
(7, '1', '1', '2022-06-24', '20:36:00', 1),
(8, '1', '12', '2022-06-10', '13:33:00', 1);


-- Table structure for table `specialties`
DROP TABLE IF EXISTS `specialties`;
CREATE TABLE IF NOT EXISTS `specialties` (
  `specialtyid` int(2) NOT NULL,
  `sname` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`specialtyid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


-- Dumping data for table `specialties`
INSERT INTO `specialties` (`specialtyid`, `sname`) VALUES
(1, 'Accident and emergency medicine'),
(2, 'Allergology'),
(3, 'Anaesthetics'),
(4, 'Biological hematology'),
(5, 'Cardiology'),
(6, 'Child psychiatry'),
(7, 'Clicnical biology'),
(8, 'Clicnical chemistry'),
(9, 'Clicnical neurophysiology'),
(10, 'Clicnical radiology'),
(11, 'Dental, oral and maxillo-facial surgery'),
(12, 'Dermato-venerology'),
(13, 'Dermatology'),
(14, 'Endocrinology'),
(15, 'Gastro-enterologic surgery'),
(16, 'Gastroenterology'),
(17, 'General hematology'),
(18, 'General Practice'),
(19, 'General surgery'),
(20, 'Geriatrics'),
(21, 'Immunology'),
(22, 'Infectious diseases'),
(23, 'Internal medicine'),
(24, 'Laboratory medicine'),
(25, 'Maxillo-facial surgery'),
(26, 'Microbiology'),
(27, 'Nephrology'),
(28, 'Neuro-psychiatry'),
(29, 'Neurology'),
(30, 'Neurosurgery'),
(31, 'Nuclear medicine'),
(32, 'Obstetrics and gynecology'),
(33, 'Occupational medicine'),
(34, 'Ophthalmology'),
(35, 'Orthopaedics'),
(36, 'Otorhinolaryngology'),
(37, 'Paediatric surgery'),
(38, 'Paediatrics'),
(39, 'Pathology'),
(40, 'Pharmacology'),
(41, 'Physical medicine and rehabilitation'),
(42, 'Plastic surgery'),
(43, 'Podiatric Medicine'),
(44, 'Podiatric Surgery'),
(45, 'Psychiatry'),
(46, 'Public health and Preventive Medicine'),
(47, 'Radiology'),
(48, 'Radiotherapy'),
(49, 'Respiratory medicine'),
(50, 'Rheumatology'),
(51, 'Stomatology'),
(52, 'Thoracic surgery'),
(53, 'Tropical medicine'),
(54, 'Urology'),
(55, 'Vascular surgery'),
(56, 'Venereology');



-- Table structure for table `webuser`
DROP TABLE IF EXISTS `webuser`;
CREATE TABLE IF NOT EXISTS `webuser` (
  `email` varchar(255) NOT NULL,
  `usertype` char(1) DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

ALTER TABLE `appointment`
ADD CONSTRAINT `fk_patient`
FOREIGN KEY (`pid`) REFERENCES `patient`(`pid`),
ADD CONSTRAINT `fk_schedule`
FOREIGN KEY (`scheduleid`) REFERENCES `schedule`(`scheduleid`);

ALTER TABLE `doctor`
ADD CONSTRAINT `fk_specialty`
FOREIGN KEY (`specialtyid`) REFERENCES `specialties`(`specialtyid`);

ALTER TABLE `schedule`
ADD CONSTRAINT `fk_doctor`
FOREIGN KEY (`docid`) REFERENCES `doctor`(`docid`);

-- Dumping data for table `webuser`
INSERT INTO `webuser` (`email`, `usertype`) VALUES
('admin@medconnect.com', 'a'),
('doctor@medconnect.com', 'd'),
('patient@medconnect.com', 'p');
COMMIT;

---- Set the delimiter to $$ so that we can define trigger logic
DELIMITER $$

-- Trigger for INSERT on patient table
CREATE TRIGGER patient_insert
AFTER INSERT ON patient
FOR EACH ROW
BEGIN
  INSERT INTO audit_log (action, table_name, record_id, new_value)
  VALUES ('INSERT', 'patient', NEW.pid, CONCAT('pemail: ', NEW.pemail, ', pname: ', NEW.pname));
END$$

-- Trigger for UPDATE on patient table
CREATE TRIGGER patient_update
AFTER UPDATE ON patient
FOR EACH ROW
BEGIN
  INSERT INTO audit_log (action, table_name, record_id, old_value, new_value)
  VALUES ('UPDATE', 'patient', NEW.pid, 
          CONCAT('pemail: ', OLD.pemail, ', pname: ', OLD.pname),
          CONCAT('pemail: ', NEW.pemail, ', pname: ', NEW.pname));
END$$

-- Trigger for DELETE on patient table
CREATE TRIGGER patient_delete
BEFORE DELETE ON patient
FOR EACH ROW
BEGIN
  INSERT INTO audit_log (action, table_name, record_id, old_value)
  VALUES ('DELETE', 'patient', OLD.pid, CONCAT('pemail: ', OLD.pemail, ', pname: ', OLD.pname));
END$$

-- Trigger for INSERT on appointment table
CREATE TRIGGER appointment_insert
AFTER INSERT ON appointment
FOR EACH ROW
BEGIN
  INSERT INTO audit_log (action, table_name, record_id, new_value)
  VALUES ('INSERT', 'appointment', NEW.appoid, CONCAT('pid: ', NEW.pid, ', scheduleid: ', NEW.scheduleid, ', appodate: ', NEW.appodate));
END$$

-- Trigger for UPDATE on appointment table
CREATE TRIGGER appointment_update
AFTER UPDATE ON appointment
FOR EACH ROW
BEGIN
  INSERT INTO audit_log (action, table_name, record_id, old_value, new_value)
  VALUES ('UPDATE', 'appointment', NEW.appoid, 
          CONCAT('pid: ', OLD.pid, ', scheduleid: ', OLD.scheduleid, ', appodate: ', OLD.appodate),
          CONCAT('pid: ', NEW.pid, ', scheduleid: ', NEW.scheduleid, ', appodate: ', NEW.appodate));
END$$

-- Trigger for DELETE on appointment table
CREATE TRIGGER appointment_delete
BEFORE DELETE ON appointment
FOR EACH ROW
BEGIN
  INSERT INTO audit_log (action, table_name, record_id, old_value)
  VALUES ('DELETE', 'appointment', OLD.appoid, CONCAT('pid: ', OLD.pid, ', scheduleid: ', OLD.scheduleid, ', appodate: ', OLD.appodate));
END$$

-- Trigger for INSERT on doctor table
CREATE TRIGGER doctor_insert
AFTER INSERT ON doctor
FOR EACH ROW
BEGIN
  INSERT INTO audit_log (action, table_name, record_id, new_value)
  VALUES ('INSERT', 'doctor', NEW.docid, CONCAT('docname: ', NEW.docname, ', docemail: ', NEW.docemail));
END$$

-- Trigger for UPDATE on doctor table
CREATE TRIGGER doctor_update
AFTER UPDATE ON doctor
FOR EACH ROW
BEGIN
  INSERT INTO audit_log (action, table_name, record_id, old_value, new_value)
  VALUES ('UPDATE', 'doctor', NEW.docid, 
          CONCAT('docname: ', OLD.docname, ', docemail: ', OLD.docemail),
          CONCAT('docname: ', NEW.docname, ', docemail: ', NEW.docemail));
END$$

-- Trigger for DELETE on doctor table
CREATE TRIGGER doctor_delete
BEFORE DELETE ON doctor
FOR EACH ROW
BEGIN
  INSERT INTO audit_log (action, table_name, record_id, old_value)
  VALUES ('DELETE', 'doctor', OLD.docid, CONCAT('docname: ', OLD.docname, ', docemail: ', OLD.docemail));
END$$

-- Trigger for INSERT on schedule table
CREATE TRIGGER schedule_insert
AFTER INSERT ON schedule
FOR EACH ROW
BEGIN
  INSERT INTO audit_log (action, table_name, record_id, new_value)
  VALUES ('INSERT', 'schedule', NEW.scheduleid, CONCAT('docid: ', NEW.docid, ', title: ', NEW.title, ', scheduledate: ', NEW.scheduledate, ', scheduletime: ', NEW.scheduletime));
END$$

-- Trigger for UPDATE on schedule table
CREATE TRIGGER schedule_update
AFTER UPDATE ON schedule
FOR EACH ROW
BEGIN
  INSERT INTO audit_log (action, table_name, record_id, old_value, new_value)
  VALUES ('UPDATE', 'schedule', NEW.scheduleid, 
          CONCAT('docid: ', OLD.docid, ', title: ', OLD.title, ', scheduledate: ', OLD.scheduledate, ', scheduletime: ', OLD.scheduletime),
          CONCAT('docid: ', NEW.docid, ', title: ', NEW.title, ', scheduledate: ', NEW.scheduledate, ', scheduletime: ', NEW.scheduletime));
END$$

-- Trigger for DELETE on schedule table
CREATE TRIGGER schedule_delete
BEFORE DELETE ON schedule
FOR EACH ROW
BEGIN
  INSERT INTO audit_log (action, table_name, record_id, old_value)
  VALUES ('DELETE', 'schedule', OLD.scheduleid, CONCAT('docid: ', OLD.docid, ', title: ', OLD.title, ', scheduledate: ', OLD.scheduledate, ', scheduletime: ', OLD.scheduletime));
END$$

-- Trigger for INSERT on specialties table
CREATE TRIGGER specialties_insert
AFTER INSERT ON specialties
FOR EACH ROW
BEGIN
  INSERT INTO audit_log (action, table_name, record_id, new_value)
  VALUES ('INSERT', 'specialties', NEW.specialtyid, CONCAT('sname: ', NEW.sname));
END$$

-- Trigger for UPDATE on specialties table
CREATE TRIGGER specialties_update
AFTER UPDATE ON specialties
FOR EACH ROW
BEGIN
  INSERT INTO audit_log (action, table_name, record_id, old_value, new_value)
  VALUES ('UPDATE', 'specialties', NEW.specialtyid, 
          CONCAT('sname: ', OLD.sname),
          CONCAT('sname: ', NEW.sname));
END$$

-- Trigger for DELETE on specialties table
CREATE TRIGGER specialties_delete
BEFORE DELETE ON specialties
FOR EACH ROW
BEGIN
  INSERT INTO audit_log (action, table_name, record_id, old_value)
  VALUES ('DELETE', 'specialties', OLD.specialtyid, CONCAT('sname: ', OLD.sname));
END$$

-- Reset the delimiter to default ;
DELIMITER ;Audit log table creation
CREATE TABLE IF NOT EXISTS audit_log (
  log_id INT AUTO_INCREMENT PRIMARY KEY,  -- Use AUTO_INCREMENT for MySQL
  action VARCHAR(50),
  table_name VARCHAR(50),
  record_id INT,
  old_value TEXT,  -- Use TEXT instead of CLOB
  new_value TEXT,  -- Use TEXT instead of CLOB
  timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
